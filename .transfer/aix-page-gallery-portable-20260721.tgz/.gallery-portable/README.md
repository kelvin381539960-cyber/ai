# AIX Page Gallery Portable Capture

- `site/`: Expo static export
- `config/pageRegistry.json`: generated route inventory
- `capture-mac.js`: Mac Chrome batch screenshot runner
- Output: `screenshots/`, `capture-results.json`, `capture-results.csv`
