const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright-core');

const root = __dirname;
const registry = require(path.join(root, 'config', 'pageRegistry.json'));
const baseUrl = process.env.GALLERY_BASE_URL || 'http://127.0.0.1:19006';
const outputRoot = process.env.GALLERY_OUTPUT || path.join(root, 'screenshots');
const limit = Number(process.env.GALLERY_LIMIT || 0);
const chromePath = process.env.CHROME_PATH ||
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';

const defaultParams = {
  preview: '1', scenario: 'default', transactionId: 'preview-card-payment',
  cardId: 'preview-card-001', messageId: 'preview-message-001', id: 'preview-id',
  type: 'VIRTUAL', status: 'SUCCESS', resultType: 'success',
  fullName: 'Preview User', originalFullName: 'Preview User', countryCode: 'SG',
  currency: 'USDT', network: 'ETH', networkCode: 'ETH', asset: 'USDT', amount: '100',
  sellCurrency: 'USDT', buyCurrency: 'USDC', nextPath: '/aix/debug/page-gallery',
  modal: 'card', nextParams: '{}',
};
defaultParams.kycNavParams = JSON.stringify({
  currentCountryISO: 'SG', currentDisplayName: 'Singapore',
  allowCountryISOList: ['SG', 'HK', 'US'],
});
defaultParams.depositMethod = JSON.stringify({
  method: 'EXCHANGE', displayName: 'Exchange',
  description: 'Preview deposit method', currencies: [], order: 1,
});

function safeName(value) {
  return value.replace(/^\//, '').replace(/[^a-zA-Z0-9._-]+/g, '-');
}
function buildUrl(item) {
  const url = new URL(`${item.route}.html`, baseUrl);
  const params = { ...defaultParams };
  for (const name of item.params || []) params[name] ??= `preview-${name}`;
  for (const [key, value] of Object.entries(params)) url.searchParams.set(key, value);
  return url.toString();
}
function csvEscape(value) {
  return `"${String(value ?? '').replace(/"/g, '""')}"`;
}
async function main() {
  fs.rmSync(outputRoot, { recursive: true, force: true });
  fs.mkdirSync(outputRoot, { recursive: true });
  const browser = await chromium.launch({
    executablePath: chromePath,
    headless: true,
    args: ['--disable-background-networking', '--disable-component-update'],
  });
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, locale: 'en-US',
  });
  await context.route('**/*', async route => {
    const requestUrl = new URL(route.request().url());
    const allowed = ['data:', 'blob:'].includes(requestUrl.protocol) ||
      ['127.0.0.1', 'localhost'].includes(requestUrl.hostname);
    allowed ? await route.continue() : await route.abort('blockedbyclient');
  });
  const candidates = registry.filter(item => !item.internal);
  const items = limit > 0 ? candidates.slice(0, limit) : candidates;
  const results = [];

  for (const [index, item] of items.entries()) {
    const page = await context.newPage();
    const pageErrors = [];
    const consoleErrors = [];
    page.on('pageerror', error => pageErrors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error') consoleErrors.push(message.text());
    });
    const directory = path.join(outputRoot, item.category);
    fs.mkdirSync(directory, { recursive: true });
    const screenshot = path.join(directory, `${safeName(item.route)}.png`);
    let navigationError = '';
    let text = '';
    try {
      await page.goto(buildUrl(item), { waitUntil: 'domcontentloaded', timeout: 30000 });
      await page.waitForTimeout(1800);
      text = await page.locator('body').innerText({ timeout: 5000 }).catch(() => '');
      await page.screenshot({ path: screenshot, fullPage: true });
    } catch (error) {
      navigationError = error instanceof Error ? error.message : String(error);
      await page.screenshot({ path: screenshot, fullPage: true }).catch(() => undefined);
    }
    const looksLikeError = /Application Error|Unexpected Application Error|TurboModuleRegistry|getEnforcing|Cannot read properties|Invariant Violation|Module not found/i.test(text);
    const status = navigationError || pageErrors.length || looksLikeError
      ? 'error' : text.trim().length > 0 ? 'rendered' : 'blank';
    results.push({
      route: item.route, category: item.category, status,
      screenshot: path.relative(root, screenshot), bodyTextLength: text.trim().length,
      navigationError, pageErrors, consoleErrors: consoleErrors.slice(0, 10),
    });
    console.log(`[${index + 1}/${items.length}] ${status} ${item.route}`);
    await page.close();
  }

  await browser.close();
  fs.writeFileSync(path.join(root, 'capture-results.json'), JSON.stringify(results, null, 2) + '\n');
  const csv = [
    ['route', 'category', 'status', 'screenshot', 'error'].map(csvEscape).join(','),
    ...results.map(item => [
      item.route, item.category, item.status, item.screenshot,
      item.navigationError || item.pageErrors.join(' | '),
    ].map(csvEscape).join(',')),
  ].join('\n') + '\n';
  fs.writeFileSync(path.join(root, 'capture-results.csv'), csv);
  const counts = results.reduce((map, item) => {
    map[item.status] = (map[item.status] || 0) + 1;
    return map;
  }, {});
  console.log('Summary:', counts);
}
main().catch(error => { console.error(error); process.exitCode = 1; });
