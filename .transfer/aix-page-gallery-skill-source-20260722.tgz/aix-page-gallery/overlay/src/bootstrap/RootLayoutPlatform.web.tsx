export { default } from './RootLayoutWeb';
