export { default } from './RootLayoutNative';
